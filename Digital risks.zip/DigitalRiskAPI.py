import numpy as np
import pandas as pd
import requests as request
import json

username = "readonly"
password = "8hL6dPmX7LqHgLx"


for x in range(0,1000):
  eventid = x
  path = "http://167.99.81.240:2113/streams/quotes-data-engineering/"+str(eventid)
  a = request.get(path,auth=(username,password),headers={'Accept': 'application/json'})
  b = a.json() # re
  filepath = "C:\\Users\\mat.shephard\\.spyder-py3\\Events\\"+str(eventid)+".txt" # create file path
  rawData = json.dumps(b)
  z = open(filepath,'w+')
  z.write(rawData)
  z.close()
  
