import pyspark.sql.functions as f
import pyspark.sql.types as t

def get_list_from_dataframe(dataframe,column):
  column_select = dataframe.select(column)
  column_list = [str(row[column]) for row in column_select.collect()]
  return column_list

quotes = spark.range(1).toDF("quoteId")
quote_item = spark.createDataFrame([('test','test','test',)],['quoteId','name','status'])

for x in range(1,2): # loop throug all events
  try:
    eventid = x
    files = "/FileStore/Events/"+str(eventid)+".txt"
    data = spark.read.option("multiline", "true").json(files)
    data1 = data.select(f.explode(f.col("products.rates")),f.col("products.name").alias("name"),"quoteId",)
    data2 = data1.select("col.status","name","quoteId")
    quote = data1.select("quoteId")
    quotes = quotes.union(quote) # append new row to df
    quote_items = data2.select("quoteId",f.col(t.StringType("name")),"status")
    quote_item = quote_item.union(quote_items) # append new rolw to df
    
  except:
    print("Not a product event") # catch errors where events are not product events
    
#write quotes to file/table then perform queries on file
#write quote_item to file and then perform queries on file
# look for anything with a status of active - select count(*), quoteId, productname from quotes join quote_item using(quoteId) where status = active
# include date for range calculations
# include 

